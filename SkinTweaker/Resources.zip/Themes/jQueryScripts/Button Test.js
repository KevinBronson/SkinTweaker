	$(function () {
		$("button").button();
		$("input:button").button();
		$("input:reset").button();
		$("input:submit").button();
		$('[id*="LinkButton"]').button();
	});