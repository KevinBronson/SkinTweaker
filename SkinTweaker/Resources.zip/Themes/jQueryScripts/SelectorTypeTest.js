	$(function () {
		$("[attrib]").animate(par1);
		$(".class").toggleClass(par2);
		$("element").addClass(par3);
		$("#id").removeClass(par4);
		$("input:button").switchClass(par5);
	});