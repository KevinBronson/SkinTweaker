	$(function () {
$(window).bind("load", function () {$(".ui-dialog").not(".dnnFormPopup").wrap('<div class="SkinTweaker"></div>');});
		$("[]").();
		$("[]").();
	});