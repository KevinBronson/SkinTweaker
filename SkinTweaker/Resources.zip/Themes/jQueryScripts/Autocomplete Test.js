	$(function () {
$(window).bind("load", function () {$(".ui-autocomplete").not('[class~="dnnForm"]').wrap('<div class="SkinTweaker"></div>');});
	});