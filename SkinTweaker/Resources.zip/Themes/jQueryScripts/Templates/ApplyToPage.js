﻿$(function () {
    $("#Body").addClass("SkinTweaker");
});